//Jonathan Avezbaki Collision Demo 2016 
#ifdef _WINDOWS
#include <GL/glew.h>
#endif
#include <SDL.h>
#include <SDL_mixer.h>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>
#ifdef _WINDOWS
#define RESOURCE_FOLDER ""
#else
#define RESOURCE_FOLDER "NYUCodebase.app/Contents/Resources/"
#endif
#include <map>
#include "Entity.h"
#include "Vector3.h"

#define FIXED_TIMESTEP 0.0166666f
#define MAX_TIMESTEPS 6

//Window 
SDL_Event event;
SDL_Window* displayWindow;
ShaderProgram* program;

//matrices
Matrix projectionMatrix;
Matrix modelMatrix;
Matrix viewMatrix;

//Entities
Entity* triangle;
Entity* rectangleOne;
Entity* rectangleTwo;

//time keeping
float elapsed = 0.0;
float lastFrameTicks = 0.0f;
float framesPerSecond = 30.0f;
float angle = 0.0;

//animation
float animationElapsed = 0.0f;
bool nextFrame = false;
int currentFrameIndex = 0;

std::vector<float> times;

//function signatures
void Setup();
void Update();
void UpdateTitleScreen();
void UpdateControls();
void ProcessEvents(bool &done);
void Render();
void RenderTitleScreen();
void RenderControls();
int Cleanup();
void TimeKeep();
void EntityMotionAndCollision(float timeElapsed);
bool checkSATCollision(const std::vector<Vector3> &e1Points, const std::vector<Vector3> &e2Points);
bool testSATSeparationForEdge(float edgeX, float edgeY, const std::vector<Vector3> &points1, const std::vector<Vector3> &points2);
void applyTransformation(Entity ent, Matrix &temp);
void checkCollision(Entity* shapeOne, Entity* shapeTwo, Matrix &temp, float timeElapsed);
void DrawText(ShaderProgram *program, int fontTexture, std::string text, float size, float spacing, Vector3 translation);

int main(int argc, char *argv[])
{
	Setup();
	bool done = false;
	while (!done) {
		ProcessEvents(done);
		Update();
		Render();
	}
	return Cleanup();
}

void Setup()
{
	//Window setup
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Demo", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 720, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);
#ifdef _WINDOWS
	glewInit();
#endif

	//view size
	glViewport(0, 0, 640, 720);
	program = new ShaderProgram(RESOURCE_FOLDER"vertex.glsl", RESOURCE_FOLDER"fragment.glsl");

	//Allow transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//orthographic projection
	projectionMatrix.setOrthoProjection(-3.55, 3.55, -4.0f, 4.0f, -1.0f, 1.0f);
	glUseProgram(program->programID);
	program->setModelMatrix(modelMatrix);
	program->setProjectionMatrix(projectionMatrix);
	program->setViewMatrix(viewMatrix);

	//polygons
	triangle = new Entity(Vector3(-1.0,0.0,0.0), Vector3(1.5,1.5,0.0), Vector3(1.5, 1.5, 0.0), Vector3((25 * M_PI) / 180, 0.0,0.0), true);
	rectangleOne = new Entity(Vector3(2.0, 2.0, 0.0), Vector3(0.5, 0.5, 0.0), Vector3(-1.5, -1.5, 0.0), Vector3((10 * M_PI) / 180, 0.0, 0.0), false);
	rectangleTwo = new Entity(Vector3(1.5, -1.5, 0.0), Vector3(0.3, 0.3, 0.3), Vector3(-0.5,0.5,0.0), Vector3(15 * M_PI / 180, 0.0, 0.0), false);

}

void Update()
{
	//clear the screen
	glClear(GL_COLOR_BUFFER_BIT);

	//update time variables
	TimeKeep();

	float fixedElapsed = elapsed;
	if (fixedElapsed > (FIXED_TIMESTEP * MAX_TIMESTEPS))
		fixedElapsed = FIXED_TIMESTEP * MAX_TIMESTEPS;

	while (fixedElapsed > FIXED_TIMESTEP)
	{
		fixedElapsed -= FIXED_TIMESTEP;
		EntityMotionAndCollision(FIXED_TIMESTEP);
	}
	EntityMotionAndCollision(fixedElapsed);
}

void EntityMotionAndCollision(float timeElapsed)
{
	//times.push_back(timeElapsed);
	Matrix temp;
	bool triFlip = false;
	bool recOneFlip = false;
	bool recTwoFlip = false;

	//move the polygons
	triangle->move(timeElapsed);
	rectangleOne->move(timeElapsed);
	rectangleTwo->move(timeElapsed);

	checkCollision(triangle, rectangleOne, temp, timeElapsed);
	checkCollision(triangle, rectangleTwo, temp, timeElapsed);
	checkCollision(rectangleOne, rectangleTwo, temp, timeElapsed);
}

void ProcessEvents(bool &done)
{
	bool buttonPush = false;
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
			done = true;
		}
	}
}

void Render()
{
	//draw the polygons
	triangle->DrawPolygon(program, modelMatrix);
	rectangleOne->DrawPolygon(program, modelMatrix);
	rectangleTwo->DrawPolygon(program, modelMatrix);

	SDL_GL_SwapWindow(displayWindow);
}

int Cleanup()
{
	SDL_Quit();
	return 0;
}

void TimeKeep()
{
	//general time keep
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	elapsed = ticks - lastFrameTicks;
	angle += elapsed;
	lastFrameTicks = ticks;
	if (elapsed == 0.0f)
		ticks = 0.0;
}

bool testSATSeparationForEdge(float edgeX, float edgeY, const std::vector<Vector3> &points1, const std::vector<Vector3> &points2) {
	float normalX = -edgeY;
	float normalY = edgeX;
	float len = sqrtf(normalX*normalX + normalY*normalY);
	normalX /= len;
	normalY /= len;

	std::vector<float> e1Projected;
	std::vector<float> e2Projected;

	for (int i = 0; i < points1.size(); i++) {
		e1Projected.push_back(points1[i].x * normalX + points1[i].y * normalY);
	}
	for (int i = 0; i < points2.size(); i++) {
		e2Projected.push_back(points2[i].x * normalX + points2[i].y * normalY);
	}

	std::sort(e1Projected.begin(), e1Projected.end());
	std::sort(e2Projected.begin(), e2Projected.end());

	float e1Min = e1Projected[0];
	float e1Max = e1Projected[e1Projected.size() - 1];
	float e2Min = e2Projected[0];
	float e2Max = e2Projected[e2Projected.size() - 1];
	float e1Width = fabs(e1Max - e1Min);
	float e2Width = fabs(e2Max - e2Min);
	float e1Center = e1Min + (e1Width / 2.0);
	float e2Center = e2Min + (e2Width / 2.0);
	float dist = fabs(e1Center - e2Center);
	float p = dist - ((e1Width + e2Width) / 2.0);

	if (p < 0) {
		return true;
	}
	return false;
}

bool checkSATCollision(const std::vector<Vector3> &e1Points, const std::vector<Vector3> &e2Points) {
	for (int i = 0; i < e1Points.size(); i++) {
		float edgeX, edgeY;

		if (i == e1Points.size() - 1) {
			edgeX = e1Points[0].x - e1Points[i].x;
			edgeY = e1Points[0].y - e1Points[i].y;
		}
		else {
			edgeX = e1Points[i + 1].x - e1Points[i].x;
			edgeY = e1Points[i + 1].y - e1Points[i].y;
		}

		bool result = testSATSeparationForEdge(edgeX, edgeY, e1Points, e2Points);
		if (!result) {
			return false;
		}
	}
	for (int i = 0; i < e2Points.size(); i++) {
		float edgeX, edgeY;

		if (i == e2Points.size() - 1) {
			edgeX = e2Points[0].x - e2Points[i].x;
			edgeY = e2Points[0].y - e2Points[i].y;
		}
		else {
			edgeX = e2Points[i + 1].x - e2Points[i].x;
			edgeY = e2Points[i + 1].y - e2Points[i].y;
		}
		bool result = testSATSeparationForEdge(edgeX, edgeY, e1Points, e2Points);
		if (!result) {
			return false;
		}
	}
	return true;
}

void applyTransformation(Entity ent, Matrix &temp)
{
	temp.identity();
	if (!ent.position.isEmpty())
		temp.Translate(ent.position.x, ent.position.y, ent.position.z);
	if (!ent.scale.isEmpty())
		temp.Scale(ent.scale.x, ent.scale.y, ent.scale.z);
	if (!ent.rotate.isEmpty())
		temp.Rotate(ent.rotate.x);

}

void checkCollision(Entity* shapeOne, Entity* shapeTwo, Matrix &temp, float timeElapsed)
{
	//move the polygons
	shapeOne->move(timeElapsed);
	shapeTwo->move(timeElapsed);
	rectangleTwo->move(timeElapsed);

	//word space coordinates
	applyTransformation(*shapeOne, temp);
	std::vector<Vector3> shapeOneCoords = shapeOne->worldSpace(temp);
	applyTransformation(*shapeTwo, temp);
	std::vector<Vector3> shapeTwoCoords = shapeTwo->worldSpace(temp);

	int maxChecks = 10;
	bool check = false;
	while (checkSATCollision(shapeOneCoords, shapeTwoCoords) && maxChecks > 0) {

		Vector3 responseVector = Vector3(shapeOne->position.x - shapeTwo->position.x, shapeOne->position.y - shapeTwo->position.y);

		responseVector.normalize();

		shapeOne->position.x -= responseVector.x * 0.001;
		shapeOne->position.y -= responseVector.y * 0.001;

		shapeTwo->position.x += responseVector.x * 0.001;
		shapeTwo->position.y += responseVector.y * 0.001;

		maxChecks -= 1;

		applyTransformation(*shapeOne, temp);
		std::vector<Vector3> shapeOneCoords = shapeOne->worldSpace(temp);
		applyTransformation(*shapeTwo, temp);
		std::vector<Vector3> shapeTwoCoords = shapeTwo->worldSpace(temp);

		check = true;
	}
	if (check)
	{
		shapeOne->velocity.x = -shapeOne->velocity.x;
		shapeOne->velocity.y = -shapeOne->velocity.y;

		shapeTwo->velocity.x = -shapeTwo->velocity.x;
		shapeTwo->velocity.y = -shapeTwo->velocity.y;
	}

	//wall collisions
	shapeOne->WallCollision(shapeOneCoords);
	shapeTwo->WallCollision(shapeTwoCoords);
}