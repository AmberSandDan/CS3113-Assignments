#ifndef ENTITY_H
#define ENTITY_H
#include "ShaderProgram.h"
#include <string>
#include <vector>
#include "Vector3.h"

class Entity
{
private:
	std::string sheetName;
	std::string imgName;
	Vector3 dimensions; //determined from the image name
	float vertices[12];
	GLuint texture;
	Vector3 uvCoords; //determined from the image name
	GLfloat textureCoordinates[12];

public:
	Entity(const std::string sheetName_, const std::string imgName_, const GLuint texture_,
		const Vector3 position_, const Vector3 scale_, const Vector3 velocity_, const Vector3 rotate_);
	static GLuint LoadTexture(const std::string image);
	void Draw(ShaderProgram* program, Matrix &modelMatrix);
	
	Vector3 getDimensions();
	Vector3 position;
	Vector3 scale; 
	Vector3 rotate;
	Vector3 velocity;
};

#endif 