//Jonathan Avezbaki Platformer 2016 
#ifdef _WINDOWS
#include <GL/glew.h>
#endif
#include <SDL.h>
#include <SDL_mixer.h>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#ifdef _WINDOWS
#define RESOURCE_FOLDER ""
#else
#define RESOURCE_FOLDER "NYUCodebase.app/Contents/Resources/"
#endif
#include <map>
#include "Entity.h"
#include "Vector3.h"

#define FIXED_TIMESTEP 0.0166666f
#define MAX_TIMESTEPS 6

#define TILE_SIZE 0.6f
#define LEVEL_HEIGHT 14 
#define LEVEL_WIDTH 52 
#define SPRITE_COUNT_X 16 
#define SPRITE_COUNT_Y 8 
float move = 0.0f;
int total = 0; 

//Window 
SDL_Event event;
SDL_Window* displayWindow;
ShaderProgram* program;

//game state
enum GameState { TITLE_SCREEN, GAME, GAME_OVER, GAME_WIN };
int state = TITLE_SCREEN;

//matrices
Matrix projectionMatrix;
Matrix modelMatrix;
Matrix viewMatrix;

//textures
GLuint fontTexture;
Entity::ImageData spriteImgData;

//entities
Entity* player;
std::vector<Entity> items;
std::vector<Entity> tiles;
Entity* finishingSpot;
Entity* badItem;

//map
int mapHeight;
int mapWidth;
unsigned char levelData[LEVEL_HEIGHT][LEVEL_WIDTH];
std::vector<float> vertexMapData;
std::vector<float> texCoordMapData;

//audio
Mix_Chunk *getOrb;
Mix_Chunk *land;
Mix_Music *music;


//time keeping
float elapsed = 0.0;
float lastFrameTicks;
float animationElapsed;
float framesPerSecond = 30.0f;
int currentIndex = 0;
bool nextFrame = false;
float angle = 0.0;

//function signatures
void Setup();
void RenderGame();
void RenderTitle();
void UpdateGame();
void UpdateTitle();
void ProcessEvents(bool &done);
void Render();
void Update();
int Cleanup();
void TimeKeep();
float enemiesHitWall();
void RenderGameOver();
void RenderGameWin();
void ParseMap();
void GenerateMap();
void GenerateMapData();
void placeEntity(std::string type, float placeX, float placeY);
bool readEntityData(std::ifstream &stream);
bool readHeader(std::ifstream &stream);
bool readLayerData(std::ifstream &stream);
void DrawMap();
void moveViewMatrix();
void RenderTitleScreen();
void DrawText(ShaderProgram *program, int fontTexture, std::string text, float size, float spacing, Vector3 translation);

int main(int argc, char *argv[])
{
	Setup();
	bool done = false;
	while (!done) {
		ProcessEvents(done);
		Update();
		Render();
	}
	return Cleanup();
}

void Setup()
{
	//Window setup
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Platformer", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 720, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);
	#ifdef _WINDOWS
		glewInit();
	#endif

	//view size
	glViewport(0, 0, 640, 720);
	program = new ShaderProgram(RESOURCE_FOLDER"vertex_textured.glsl", RESOURCE_FOLDER"fragment_textured.glsl");

	//Allow transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//for time keeping
	lastFrameTicks = 0.0f;

	//orthographic projection
	projectionMatrix.setOrthoProjection(-3.55, 3.55, -4.0f, 4.0f, -1.0f, 1.0f);
	glUseProgram(program->programID);
	program->setModelMatrix(modelMatrix);
	program->setProjectionMatrix(projectionMatrix);
	program->setViewMatrix(viewMatrix);

	//audio
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
	getOrb = Mix_LoadWAV("sparkle.wav");
	land = Mix_LoadWAV("land.wav");
	music = Mix_LoadMUS("castlevania.mp3");

	//textures
	spriteImgData = Entity::LoadImg("arne_sprites.png");
	fontTexture = Entity::LoadImg("font1.png").texture;

	mapWidth = LEVEL_WIDTH;
	mapHeight = LEVEL_HEIGHT;

	//generate map, player, and enemies
	ParseMap();
	GenerateMapData();
}

void ParseMap()
{
	std::ifstream infile("platformerMap.txt");
	std::string line;
	while (getline(infile, line)) {
		if (line == "[header]") {
			if (!readHeader(infile))
				return;
		}
		else if (line == "[layer]") {
			readLayerData(infile);
		}
		else if (line == "[Object Layer 1]") {
			readEntityData(infile);
		}
	}
}

void GenerateMapData()
{
	std::vector<int> mkay;
	//Sets up all vertex and texture coordinates
	for (int y = 0; y < LEVEL_HEIGHT; y++) {
		for (int x = 0; x < LEVEL_WIDTH; x++) {
			
			if (levelData[y][x] != 0)
			{
				++total;
				float u = (float)(((int)levelData[y][x]) % SPRITE_COUNT_X) / (float)SPRITE_COUNT_X;
				float v = (float)(((int)levelData[y][x]) / SPRITE_COUNT_X) / (float)SPRITE_COUNT_Y;

				float spriteWidth = 1.0f / (float)SPRITE_COUNT_X;
				float spriteHeight = 1.0f / (float)SPRITE_COUNT_Y;
				
				mkay.push_back((int)levelData[y][x]);

				vertexMapData.insert(vertexMapData.end(), {
				TILE_SIZE * x, -TILE_SIZE * y,
				TILE_SIZE * x, (-TILE_SIZE * y) - TILE_SIZE,
				(TILE_SIZE * x) + TILE_SIZE, (-TILE_SIZE * y) - TILE_SIZE,
				TILE_SIZE * x, -TILE_SIZE * y,
				(TILE_SIZE * x) + TILE_SIZE, (-TILE_SIZE * y) - TILE_SIZE,
				(TILE_SIZE * x) + TILE_SIZE, -TILE_SIZE * y
				});

				texCoordMapData.insert(texCoordMapData.end(), {
				u, v,
				u, v + (spriteHeight),
				u + spriteWidth, v + (spriteHeight),
				u, v,
				u + spriteWidth, v + (spriteHeight),
				u + spriteWidth, v
				});
			}
		}
	}
}

bool readHeader(std::ifstream &stream) {
	std::string line;
	int mapWidth = -1;
	int mapHeight = -1;
	while (getline(stream, line)) {
		if (line == "") { break; }
		std::istringstream sStream(line);
		std::string key, value;
		getline(sStream, key, '=');
		getline(sStream, value);
		if (key == "width") {
			mapWidth = atoi(value.c_str());
		}
		else if (key == "height"){
			mapHeight = atoi(value.c_str());
		}
	}
	if (mapWidth == -1 || mapHeight == -1) {
		return false;
	}
	else { // allocate our map data
		/*levelData = new unsigned char*[mapHeight];
		for (int i = 0; i < mapHeight; ++i) {
			levelData[i] = new unsigned char[mapWidth];
		}*/
		return true;
	}
}

bool readLayerData(std::ifstream &stream) {
	std::string line;
	while (getline(stream, line)) {
		if (line == "") { break; }
		std::istringstream sStream(line);
		std::string key, value;
		std::getline(sStream, key, '=');
		getline(sStream, value);
		if (key == "data") {
			for (int y = 0; y < mapHeight; y++) {
				getline(stream, line);
				std::istringstream lineStream(line);
				std::string tile;
				for (int x = 0; x < mapWidth; x++) {
					getline(lineStream, tile, ',');
					unsigned char val = (unsigned char)atoi(tile.c_str());
					if (val > 0) {
						// be careful, the tiles in this format are indexed from 1 not 0
						levelData[y][x] = val - 1;
					}
					else {
						levelData[y][x] = 0;
					}
				}
			}
		}
	}
	return true;
}

bool readEntityData(std::ifstream &stream) {
	std::string line;
	std::string type;
	while (getline(stream, line)) {
		if (line == "") { break; }
		std::istringstream sStream(line);
		std::string key, value;
		getline(sStream, key, '=');
		getline(sStream, value);
		if (key == "type") {
			type = value;
		}
		else if (key == "location") {
			std::istringstream lineStream(value);
			std::string xPosition, yPosition;
			getline(lineStream, xPosition, ',');
			getline(lineStream, yPosition, ',');
			float placeX = atoi(xPosition.c_str())*TILE_SIZE;
			float placeY = atoi(yPosition.c_str())*-TILE_SIZE;
			placeEntity(type, placeX, placeY); //place entity because you're literally drawing entities... like player and enemies.
			//the other fucntion listed in week6_class1 is meant to draw the map
		}
	}
	return true;
}

void placeEntity(std::string type, float placeX, float placeY)
{
	//place item
	if (type == "Item")
	{
		items.push_back(Entity("arne_sprites.png", 22, 16, 8, spriteImgData, TILE_SIZE,
			Vector3(placeX + TILE_SIZE / 2, placeY - TILE_SIZE / 2), Vector3(), Vector3(), Vector3(0.1,0.0,0.0), Vector3(), std::vector<int>()));
	}
	//place badItem
	else if (type == "BadItem")
	{
		badItem = new Entity(Entity("arne_sprites.png", 26, 16, 8, spriteImgData, TILE_SIZE,
			Vector3(placeX + TILE_SIZE / 2, placeY - TILE_SIZE / 2), Vector3(), Vector3(), Vector3(), Vector3(0.0001, 0.0005, 0.0), std::vector <int> {98, 99}));
	}
	//place player
	else if (type == "Starting Point") 
	{
		player = new Entity(Entity("arne_sprites.png", 98, 16, 8, spriteImgData, TILE_SIZE,
			Vector3(placeX + TILE_SIZE / 2, placeY - TILE_SIZE / 2), Vector3(), Vector3(), Vector3(), Vector3(0.0001, 0.0005 , 0.0), std::vector <int> {98 , 99}));
	}
	//place finising spot
	{
		finishingSpot = new Entity(Entity("arne_sprites.png", 48, 16, 8, spriteImgData, TILE_SIZE,
			Vector3(placeX + TILE_SIZE / 2, placeY - TILE_SIZE / 2), Vector3(), Vector3(), Vector3(), Vector3(), std::vector <int>()));
	}
}

void Update()
{
	glClear(GL_COLOR_BUFFER_BIT);
	TimeKeep();
	
	switch (state)
	{
	case GAME:
		UpdateGame();
		break;
	}
}

void ProcessEvents(bool &done)
{
	bool buttonPush = false;
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
			done = true;
		}
		else if (state == TITLE_SCREEN && event.type == SDL_KEYDOWN)
		{
			state = GAME;
			Mix_PlayMusic(music, -1);
		}
		else if (state == GAME && event.type == SDL_KEYDOWN)
		{
			//move
			switch (event.key.keysym.sym){
			case 97:
				buttonPush = true;
				if (player->velocity.y == 0)
				{
					buttonPush = true;
					player->velocity.x = -0.02;
				}
				else 
					player->velocity.x = -0.009;
				break;
			case 100:
				buttonPush = true;
				if (player->velocity.y == 0)
				{
					buttonPush = true;
					player->velocity.x = 0.02;
				}
				else
					player->velocity.x = 0.009;
				break;
			default:
				buttonPush = false;
				break;
			}
		}

		//jump
		if (event.key.keysym.scancode == SDL_SCANCODE_SPACE && player->velocity.y == 0)
   			player->velocity.y = 0.04;

		if (!buttonPush)
		{
			if (player->velocity.y == 0)
				player->velocity.x = 0;
		}
	}
}

void UpdateTitle()
{

}

void EntityMotionAndCollision(float elapsedd)
{
	float playerX;
	float playerY;

	//player motion
	if (player->velocity.x != 0 && player->velocity.y == 0)
		player->changeFrame(player->indecesOfAnimation[currentIndex], SPRITE_COUNT_X, SPRITE_COUNT_Y);
	player->move(elapsedd);

	//player grid coordinates
	int x = (int)(player->position.x / TILE_SIZE);
	int y = (int)(-player->position.y / TILE_SIZE);
	int tileNumber;

	//PLAYER + TILE BELOW COLLISION
	tileNumber = (int)(levelData[y + 1][x]);

	//there is a tile beneath the player
	if (tileNumber != 0)
	{
		playerY = player->position.y - (player->getDimensions().y*TILE_SIZE);
		float tileY = (-TILE_SIZE * (y + 1)) + (TILE_SIZE/3);

		//collision
		if (playerY < tileY)
		{
			Mix_PlayChannel(-1, land, 0);
			player->position.y += 0.026;
			player->velocity.y = 0;
			player->velocity.x = 0;
		}
	}
	else if (player->velocity.y == 0)
	{
		player->velocity.y = -0.005;
	}

	//PLAYER + TILE RIGHT COLLISION
	tileNumber = (int)(levelData[y][x + 1]);

	//there is a tile to the right of the player
	if (tileNumber != 0)
	{
		playerX = player->position.x + (player->getDimensions().x * TILE_SIZE);
		float tileX = (TILE_SIZE * (x + 1)) - (TILE_SIZE / 3);
		
		//collision
		if (playerX > tileX)
		{
			player->position.x -= 0.026;
			player->velocity.x = 0;
		}
	}

	//PLAYER + TILE LEFT COLLISION
	tileNumber = (int)(levelData[y][x - 1]);

	//there is a tile to the left of the player
	if (tileNumber != 0)
	{
		playerX = player->position.x - (player->getDimensions().x * (TILE_SIZE)) - 0.28;
		float tileX = (TILE_SIZE * (x - 1)) + (TILE_SIZE);
		
		//collision
 		if (playerX < tileX)
		{
			player->position.x += 0.026;
			player->velocity.x = 0;
		}
	}

	//PLAYER + TILE ABOVE COLLISION
	tileNumber = (int)(levelData[y - 1][x]);

	//there is a tile to the left of the player
	if (tileNumber != 0)
	{
		playerY = player->position.y - (player->getDimensions().y*TILE_SIZE) - 0.03;
		float tileY = (-TILE_SIZE * (y + 1)) + (TILE_SIZE / 3);

		//collision
		if (playerY > tileY)
		{
 			player->position.y -= 0.026;
			player->velocity.y = 0;
		}
	}

	//PLAYER + ORB COLLISION
	for (std::vector<Entity>::iterator iter = items.begin(); iter != items.end(); ++iter)
	{
		playerX = player->position.x;
		float orbX = iter->position.x;
		
		//x-axis check
		if (abs(playerX - orbX) < TILE_SIZE - 0.2)
		{
			playerY = player->position.y;
			float orbY = iter->position.y;

			//y-axis check
			if (abs(playerY - orbY) < TILE_SIZE - 0.2)
			{
				Mix_PlayChannel(-1, getOrb, 0);
				iter = items.erase(iter);
				break;
			}
		}
	}
	
	//PLAYER + BAD ORB COLLISION
	playerX = player->position.x;
	float badOrbX = badItem->position.x;

	//x-axis check
	if (abs(playerX - badOrbX) < TILE_SIZE-0.4)
	{
		playerY = player->position.y;
		float badOrbY = badItem->position.y;

		//y-axis check
		if (abs(playerY - badOrbY) < TILE_SIZE-0.2)
		{
			state = GAME_OVER;
		}
	}

	//PLAYER + FINISHING POINT
	playerX = player->position.x;
	float finishX = finishingSpot->position.x;
	
	//x-axis check
	if (abs(playerX - finishX) < TILE_SIZE - 0.2)
	{
		playerY = player->position.y;
		float finishY = finishingSpot->position.y;

		//y-axis check
		if (abs(playerY - finishY) < TILE_SIZE - 0.2 && items.size() == 0)
		{
			state = GAME_WIN;
		}
	}
	
}

void UpdateGame()
{	
	//Time
	float fixedElapsed = elapsed;
	if (fixedElapsed > (FIXED_TIMESTEP * MAX_TIMESTEPS))
		fixedElapsed = FIXED_TIMESTEP * MAX_TIMESTEPS;

	while (fixedElapsed > FIXED_TIMESTEP)
	{
		fixedElapsed -= FIXED_TIMESTEP;
		EntityMotionAndCollision(FIXED_TIMESTEP);
	}
	while (fixedElapsed < FIXED_TIMESTEP)
	{
		fixedElapsed += FIXED_TIMESTEP;
		EntityMotionAndCollision(FIXED_TIMESTEP);
	}
	EntityMotionAndCollision(fixedElapsed);
}

void Render(){

	switch (state)
	{
	case TITLE_SCREEN:
		RenderTitleScreen();
		break;
	case GAME:
		RenderGame();
		break;
	case GAME_OVER:
		RenderGameOver();
		break;
	case GAME_WIN:
		RenderGameWin();
		break;
	}

	SDL_GL_SwapWindow(displayWindow);
}

void RenderTitleScreen()
{
	DrawText(program, fontTexture, "Avoid the red orb.", 0.3f, 0.0f, Vector3(player->position.x - 2.50, player->position.y + 3.5, 0.0));
	DrawText(program, fontTexture, "Get all the blue orbs,", 0.3f, 0.0f, Vector3(player->position.x - 3.0, player->position.y + 3.0, 0.0));
	DrawText(program, fontTexture, "and then touch the star.", 0.3f, 0.0f, Vector3(player->position.x - 3.25, player->position.y + 2.5, 0.0));
	DrawText(program, fontTexture, "Press any key to begin.", 0.3f, 0.0f, Vector3(player->position.x - 3.25, player->position.y + 2.0, 0.0));
}

void RenderGameOver()
{
	DrawText(program, fontTexture, "GAME OVER", 0.4f, 0.0f, Vector3(player->position.x - 1.75, player->position.y + 3.5, 0.0));
}

void RenderGameWin()
{
	DrawText(program, fontTexture, "YOU WIN", 0.4f, 0.0f, Vector3(player->position.x - 1.25, player->position.y + 3.5, 0.0));
}

void RenderGame()
{
	DrawMap();

	//Draw the player
	player->Draw(program, modelMatrix);
	
	//Draw the items
	for each (Entity item in items)
	{
		item.rotate.x = angle * 75 * (M_PI / 180.0);
		item.Draw(program, modelMatrix);
	}
	badItem->Draw(program, modelMatrix);

	//end
	finishingSpot->Draw(program, modelMatrix);
}

int Cleanup()
{
	Mix_FreeChunk(getOrb);
	Mix_FreeChunk(land);
	Mix_FreeMusic(music);

	SDL_Quit();
	return 0;
}

//Helper Functions
void DrawText(ShaderProgram *program, int fontTexture, std::string text, float size, float spacing, Vector3 translation) {
	float texture_size = 1.0 / 16.0f;
	std::vector<float> vertexData;
	std::vector<float> texCoordData;
	for (int i = 0; i < text.size(); i++) {
		float texture_x = (float)(((int)text[i]) % 16) / 16.0f;
		float texture_y = (float)(((int)text[i]) / 16) / 16.0f;
		vertexData.insert(vertexData.end(), {
			((size + spacing) * i) + (-0.5f * size), 0.5f * size,
			((size + spacing) * i) + (-0.5f * size), -0.5f * size,
			((size + spacing) * i) + (0.5f * size), 0.5f * size,
			((size + spacing) * i) + (0.5f * size), -0.5f * size,
			((size + spacing) * i) + (0.5f * size), 0.5f * size,
			((size + spacing) * i) + (-0.5f * size), -0.5f * size,
		});
		texCoordData.insert(texCoordData.end(), {
			texture_x, texture_y,
			texture_x, texture_y + texture_size,
			texture_x + texture_size, texture_y,
			texture_x + texture_size, texture_y + texture_size,
			texture_x + texture_size, texture_y,
			texture_x, texture_y + texture_size,
		});
	}
	modelMatrix.identity(); 
	modelMatrix.Translate(translation.x, translation.y, translation.z);
	program->setModelMatrix(modelMatrix);
	glUseProgram(program->programID);
	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertexData.data());
	glEnableVertexAttribArray(program->positionAttribute);
	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoordData.data());
	glEnableVertexAttribArray(program->texCoordAttribute);
	glBindTexture(GL_TEXTURE_2D, fontTexture);
	glDrawArrays(GL_TRIANGLES, 0, text.size() * 6);
	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);
}

void DrawMap()
{
	modelMatrix.identity();
	program->setModelMatrix(modelMatrix);
	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoordMapData.data());
	glEnableVertexAttribArray(program->texCoordAttribute);

	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertexMapData.data());
	glEnableVertexAttribArray(program->positionAttribute);
	
	glBindTexture(GL_TEXTURE_2D, spriteImgData.texture);
	glDrawArrays(GL_TRIANGLES, 0, total * 6);
}

void TimeKeep()
{
	moveViewMatrix();

	//animation time keep
	animationElapsed += elapsed;
	nextFrame = false;
	if (animationElapsed > (1.0 / framesPerSecond)*5) {
		nextFrame = true;
		currentIndex++;
		animationElapsed = 0.0;

		if (currentIndex >= 2)
			currentIndex = 0;
	}

	//general time keep
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	elapsed = ticks - lastFrameTicks;
	angle += elapsed;
	lastFrameTicks = ticks;
	if (elapsed == 0.0f)
		ticks = 0.0;
}

void moveViewMatrix()
{
	if (player->position.x > 3.5 && player->position.x < 27.67)
	{
		viewMatrix.identity();
		viewMatrix.Translate(player->position.x * -1, 4.4, 0);
		program->setViewMatrix(viewMatrix);
	}
}
