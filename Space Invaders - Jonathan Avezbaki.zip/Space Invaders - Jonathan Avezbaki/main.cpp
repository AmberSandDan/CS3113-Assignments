//Jonathan Avezbaki Space Invaders 2016 
#ifdef _WINDOWS
#include <GL/glew.h>
#endif
#include <SDL.h>
#include <cmath>
#ifdef _WINDOWS
#define RESOURCE_FOLDER ""
#else
#define RESOURCE_FOLDER "NYUCodebase.app/Contents/Resources/"
#endif
#include <map>
#include "Entity.h"
#include "Vector3.h"

#define FIXED_TIMESTEP 0.0166666f
#define MAX_TIMESTEPS 6

//Window 
SDL_Event event;
SDL_Window* displayWindow;
ShaderProgram* program;

//game state
enum GameState { TITLE_SCREEN, GAME, GAME_OVER, GAME_WIN };
int state = TITLE_SCREEN;

enum WallHit {HIT_LEFT_WALL, HIT_RIGHT_WALL, HIT_NO_WALL};

//matrices
Matrix projectionMatrix;
Matrix modelMatrix;
Matrix viewMatrix;

//textures
GLuint fontTexture;
GLuint spriteTexture;

//entities & shooting
Entity* player;
std::vector<Entity> enemies;
std::vector<Entity> bullets;
std::vector<Entity> bulletsFromEnemies;
bool playerShoot = false;
int playerShootCounter = 0;

//time keeping
float elapsed = 0.0;
float lastFrameTicks;

//function signatures
void Setup();
void RenderGame();
void RenderTitle();
void UpdateGame();
void UpdateTitle();
void ProcessEvents(bool &done);
void Render();
void Update();
int Cleanup();
void TimeKeep();
float enemiesHitWall();
void RenderGameOver();
void RenderGameWin();
void DrawText(ShaderProgram *program, int fontTexture, std::string text, float size, float spacing, Vector3 translation);

int main(int argc, char *argv[])
{
	Setup();
	bool done = false;
	while (!done) {
		ProcessEvents(done);
		Update();
		Render();
	}
	return Cleanup();
}

void Setup()
{
	//Window setup
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Space Invaders", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 720, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);
	#ifdef _WINDOWS
		glewInit();
	#endif

	//view size
	glViewport(0, 0, 640, 720);
	program = new ShaderProgram(RESOURCE_FOLDER"vertex_textured.glsl", RESOURCE_FOLDER"fragment_textured.glsl");

	//Allow transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//for time keeping
	lastFrameTicks = 0.0f;

	//orthographic projection
	projectionMatrix.setOrthoProjection(-3.55, 3.55, -4.0f, 4.0f, -1.0f, 1.0f);
	glUseProgram(program->programID);
	program->setModelMatrix(modelMatrix);
	program->setProjectionMatrix(projectionMatrix);
	program->setViewMatrix(viewMatrix);

	//textures
	fontTexture = Entity::LoadTexture("font1.png");
	spriteTexture = Entity::LoadTexture("sheet.png");

	//Entities
	player = new Entity("sheet.png", "playerShip1_blue.png", spriteTexture,
		Vector3(0.0, -3.3), Vector3(), Vector3(), Vector3());

	//row number, image name
	std::map<int, std::string> enemyOrder = { { 0, "enemyBlack1.png" }, { 1, "enemyBlue1.png" }, { 2, "enemyGreen1.png" },
											  { 3, "enemyRed1.png" } };

	//5 enemies per row
	for (int i = 0; i < 5; ++i)
	{
		//4 rows
		for (int y = 0; y < 4; ++y)
		{
			Entity enemy = Entity("sheet.png", enemyOrder.find(y)->second, spriteTexture,
				Vector3(i - 3, y + 0.3), Vector3(0.5, 0.5), Vector3(0.012, 0.0), Vector3());
			enemies.push_back(enemy);
		}
	}
}

void Update()
{
	glClear(GL_COLOR_BUFFER_BIT);
	TimeKeep();
	
	switch (state)
	{
	case TITLE_SCREEN:
		UpdateTitle();
		break;
	case GAME:
		UpdateGame();
		break;
	}
}

void ProcessEvents(bool &done)
{
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
			done = true;
		}
		else if (state == TITLE_SCREEN && event.type == SDL_KEYDOWN)
			state = GAME;
		else if (state == GAME && event.type == SDL_KEYDOWN)
		{
			//move
			switch (event.key.keysym.sym){
			case 97:
				player->velocity.x = -12.3;
				break;
			case 100:
				player->velocity.x = 12.3;
				break;
			default:
				break;
			}

			//shoot
			if (event.key.keysym.scancode == SDL_SCANCODE_SPACE)
				playerShoot = true;
		}
	}
}

void UpdateTitle()
{

}

void EntityMotionAndCollision(float elapsed)
{
	//PLAYER MOVMENT
	player->position.x += elapsed * player->velocity.x;
	player->velocity.x = 0;

	//ENEMY MOVEMENT

	//Check if the enemies hit the walls
	float displacement = enemiesHitWall();
	if (displacement != 0.0f)
	{
		for (int i = 0; i < enemies.size(); ++i)
		{
			//reverse x direction
			enemies[i].velocity.x *= -1;

			//move one "step" closer to player
			enemies[i].velocity.y = -4.0;
		}
	}

	//move the enemies
	for (int i = 0; i < enemies.size(); ++i)
	{
		enemies[i].position.x += elapsed * enemies[i].velocity.x;
		if (enemies[i].position.y != 0.0)
		{
			enemies[i].position.y += elapsed * enemies[i].velocity.y;
			enemies[i].velocity.y = 0.0;
		}
	}

	//PLAYER'S BULLET MOVEMENT
	for (int i = bullets.size()-1; i >= 0; --i)
	{
		bullets[i].position.y += elapsed * bullets[i].velocity.y;
		if (bullets[i].position.y  - 0.5f > 4.0f)
			bullets.erase(bullets.begin() + i);
	}

	//ENEMIES' BULLET MOVEMENT
	for (int i = bulletsFromEnemies.size() - 1; i >= 0; --i)
	{
		bulletsFromEnemies[i].position.y += elapsed * bulletsFromEnemies[i].velocity.y;
		if (bulletsFromEnemies[i].position.y + 0.5 < -4.0f)
			bulletsFromEnemies.erase(bulletsFromEnemies.begin() + i);
	}

	//PLAYER+BULLET COLLISION

	//go through each bullet
	for (int i = 0; i < bulletsFromEnemies.size(); ++i)
	{
		//collision on y
		if (bulletsFromEnemies[i].position.y + 0.5 >= player->position.y - 0.5
			&& bulletsFromEnemies[i].position.y - 0.5 <= player->position.y + 0.5)
		{
			//collision on x
   			if (abs(bulletsFromEnemies[i].position.x - player->position.x) <= 0.6)
			{
				state = GAME_OVER;
			}
		}
	}

	//ENEMY+BULLET COLLISION

	//go through each bullet
	for (int i = 0; i < bullets.size(); ++i)
	{
		//see if any bullet collides with any enemies
		for (int y = 0; y < enemies.size(); ++y)
		{
			//collision on y
			if (bullets[i].position.y + 0.5 >= enemies[y].position.y - 0.2
				&& bullets[i].position.y - 0.5 <= enemies[y].position.y + 0.2)
			{
				//collision on x
				if (abs(bullets[i].position.x - enemies[y].position.x) <= 0.3)
				{
					//the enemy and bullet that collided are removed from the game
					enemies.erase(enemies.begin() + y);
					bullets.erase(bullets.begin() + i);
					if (enemies.size() == 0)
						state = GAME_WIN;
					--i;
					break;
				}
			}
		}
	}
}

void UpdateGame()
{	
	//Time
	float fixedElapsed = elapsed;
	if (fixedElapsed > (FIXED_TIMESTEP * MAX_TIMESTEPS))
		fixedElapsed = FIXED_TIMESTEP * MAX_TIMESTEPS;

	while (fixedElapsed > FIXED_TIMESTEP)
	{
		fixedElapsed -= FIXED_TIMESTEP;
		EntityMotionAndCollision(FIXED_TIMESTEP);
	}
	while (fixedElapsed < FIXED_TIMESTEP)
	{
		fixedElapsed += FIXED_TIMESTEP;
		EntityMotionAndCollision(FIXED_TIMESTEP);
	}
	EntityMotionAndCollision(fixedElapsed);

	//player shoots bullets
	if (playerShoot)
	{
		if (bullets.size() != 5)
		{
			Entity bullet = Entity("sheet.png", "laserBlue01.png", spriteTexture, Vector3(player->position.x, 0.0),
				Vector3(), Vector3(0.0, 0.1), Vector3()); 
			bullet.position.y = player->position.y + 1.0;
			bullets.push_back(bullet);
			playerShoot = false;
			++playerShootCounter;
		}
	}

	//3 enemies will fire bullets on every 3rd shot player shoots
	if (playerShootCounter == 3)
	{
		std::vector<int> shooterEnemies;
		int random;
		int numberOfBullets = (enemies.size() >= 3) ? 3 : enemies.size();
		for (int i = 0; i < numberOfBullets; ++i)
		{
			//Keep generating random numbers until 3 unique #s are recieved
			random = rand() % enemies.size();
			while (std::find(shooterEnemies.begin(), shooterEnemies.end(), random) != shooterEnemies.end())
			{ 
				random = rand() % enemies.size();
			}
			shooterEnemies.push_back(random);
		}

		//Generate a bullet for each enemy chosen
		for (int i = 0; i < numberOfBullets; ++i)
		{
			Entity bullet = Entity("sheet.png", "laserRed01.png", spriteTexture,
				Vector3(enemies[shooterEnemies[i]].position.x, enemies[shooterEnemies[i]].position.y - 0.7), //position
				Vector3(), //scale
				Vector3(0.0, -0.025), //velocity
				Vector3(M_PI, 0)); //rotation

			bulletsFromEnemies.push_back(bullet);
		}

 		playerShootCounter = 0;
	}
}

void Render(){

	switch (state)
	{
	case TITLE_SCREEN:
		RenderTitle();
		break;
	case GAME:
		RenderGame();
		break;
	case GAME_OVER:
		RenderGameOver();
		break;
	case GAME_WIN:
		RenderGameWin();
		break;
	}

	SDL_GL_SwapWindow(displayWindow);
}

void RenderTitle()
{
	DrawText(program, fontTexture, "SPACE INVADERS", 0.4f, 0.0f, Vector3(-2.6,0.0,0.0));
	DrawText(program, fontTexture, "Press any key to start", 0.2f, 0.0f, Vector3(-2.0, -0.65, 0.0));
}

void RenderGameOver()
{
	DrawText(program, fontTexture, "GAME OVER", 0.4f, 0.0f, Vector3(-1.6, 0.0, 0.0));
}

void RenderGameWin()
{
	DrawText(program, fontTexture, "YOU WIN", 0.4f, 0.0f, Vector3(-1.2, 0.0, 0.0));
}

void RenderGame()
{
	//player
	player->Draw(program, modelMatrix);

	//enemies
	for (int i = 0; i < enemies.size(); ++i)
	{
		enemies[i].Draw(program, modelMatrix);
	}

	//bullets from player
	for (int i = 0; i < bullets.size(); ++i)
	{
		bullets[i].Draw(program, modelMatrix);
	}

	//bullets from enemies
	for (int i = 0; i < bulletsFromEnemies.size(); ++i)
	{
		bulletsFromEnemies[i].Draw(program, modelMatrix);
	}
}

int Cleanup()
{
	SDL_Quit();
	return 0;
}

//Helper Functions
void DrawText(ShaderProgram *program, int fontTexture, std::string text, float size, float spacing, Vector3 translation) {
	float texture_size = 1.0 / 16.0f;
	std::vector<float> vertexData;
	std::vector<float> texCoordData;
	for (int i = 0; i < text.size(); i++) {
		float texture_x = (float)(((int)text[i]) % 16) / 16.0f;
		float texture_y = (float)(((int)text[i]) / 16) / 16.0f;
		vertexData.insert(vertexData.end(), {
			((size + spacing) * i) + (-0.5f * size), 0.5f * size,
			((size + spacing) * i) + (-0.5f * size), -0.5f * size,
			((size + spacing) * i) + (0.5f * size), 0.5f * size,
			((size + spacing) * i) + (0.5f * size), -0.5f * size,
			((size + spacing) * i) + (0.5f * size), 0.5f * size,
			((size + spacing) * i) + (-0.5f * size), -0.5f * size,
		});
		texCoordData.insert(texCoordData.end(), {
			texture_x, texture_y,
			texture_x, texture_y + texture_size,
			texture_x + texture_size, texture_y,
			texture_x + texture_size, texture_y + texture_size,
			texture_x + texture_size, texture_y,
			texture_x, texture_y + texture_size,
		});
	}
	modelMatrix.identity(); 
	modelMatrix.Translate(translation.x, translation.y, translation.z);
	program->setModelMatrix(modelMatrix);
	glUseProgram(program->programID);
	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertexData.data());
	glEnableVertexAttribArray(program->positionAttribute);
	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoordData.data());
	glEnableVertexAttribArray(program->texCoordAttribute);
	glBindTexture(GL_TEXTURE_2D, fontTexture);
	glDrawArrays(GL_TRIANGLES, 0, text.size() * 6);
	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);
}

void TimeKeep()
{
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	elapsed = ticks - lastFrameTicks;
	lastFrameTicks = ticks;
	if (elapsed == 0.0f)
		ticks = 0.0;
}

float enemiesHitWall()
{
	//check which wall (if any) the enemies hit
	WallHit wallH = HIT_NO_WALL;
	for (int i = 0; i < enemies.size(); ++i)
	{
		if (enemies[i].position.x > 3.0)
			wallH = HIT_RIGHT_WALL; 
		else if (enemies[i].position.x < -3.0)
			wallH = HIT_LEFT_WALL; 
	}

	//shift them over slightly so they can start moving 
	//in opposite direction
	float displacment = 0.0f;
	if (wallH == HIT_RIGHT_WALL)
		displacment = -0.025f;
	else if (wallH == HIT_LEFT_WALL)
		displacment = 0.025f;
	for (int i = 0; i < enemies.size(); ++i)
	{
		enemies[i].position.x += displacment;
	}
	return displacment;
}