#include "Entity.h"
#include <ostream>
#include <SDL_image.h>
#include "ShaderProgram.h"

GLuint Entity::LoadTexture(const std::string image)
{
	//My image 
	//Note to self, image has to be in the same folder as the rest of these files
	//Folder found by right clicking the project and opening explorer
	SDL_Surface *surface = IMG_Load(image.c_str());
	std::string error = IMG_GetError();
	if (error != "")
		std::cerr << error;

	//create a new texture id
	GLuint textureID;
	glGenTextures(1, &textureID);

	//bind a texture to a texture target
	glBindTexture(GL_TEXTURE_2D, textureID);

	//Set the texture data of the specified texture target. Slight modifications depending on OS and image format
#if defined(_WINDOWS)
	if (surface->format->BytesPerPixel == 4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface->w, surface->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, surface->pixels);
	else if (surface->format->BytesPerPixel == 3)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, surface->w, surface->h, 0, GL_RGB, GL_UNSIGNED_BYTE, surface->pixels);
	else
		std::cerr << "Having trouble reading image, it will not work with this program";
#else
	if (surface->format->BytesPerPixel == 4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_BGRA, surface->w, surface->h, 0, GL_BGRA, GL_UNSIGNED_BYTE, surface->pixels);
	else if (surface->format->BytesPerPixel == 3)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_BGR, surface->w, surface->h, 0, GL_BGR, GL_UNSIGNED_BYTE, surface->pixels);
	else
		cerr << "Having trouble reading image, it will not work with this program";
#endif	

	//Set a texture parameter of the specified texture target
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	SDL_FreeSurface(surface);

	return textureID;
}

Entity::Entity(const std::string sheetName_, const std::string imgName_, const GLuint texture_,
	const Vector3 position_, const Vector3 scale_, const Vector3 velocity_, const Vector3 rotate_) :
	imgName(imgName_), sheetName(sheetName_), texture(texture_), 
	position(position_), scale(scale_), velocity(velocity_), rotate(rotate_)
{
	bool create = false;
	std::ifstream fin("sheet.xml");
	std::string line;
	while (std::getline(fin, line))
	{
		//Check if this line has the image
		if (line.find(imgName) != std::string::npos)
		{
			create = true;
			size_t lastIndexOfName = line.find(imgName) + imgName.length();

			//grab the parameters from the line
			//u
			size_t indexOfXValue = line.find("x=\"", lastIndexOfName) + 3;
			size_t indexOfEndOfXValue = line.find("\"", indexOfXValue);
			std::string xValue = line.substr(indexOfXValue, indexOfEndOfXValue - indexOfXValue);
			uvCoords.x = atoi(xValue.c_str()) / 1024.0f;

			//v
			size_t indexOfYValue = line.find("y=\"", indexOfEndOfXValue) + 3;
			size_t indexOfEndOfYValue = line.find("\"", indexOfYValue);
			std::string YValue = line.substr(indexOfYValue, indexOfEndOfYValue - indexOfYValue);
			uvCoords.y = atoi(YValue.c_str()) / 1024.0f;

			//width
			size_t indexOfWidth= line.find("width=\"", indexOfEndOfYValue) + 7;
			size_t indexOfEndOfWidth = line.find("\"", indexOfWidth);
			std::string widthValue = line.substr(indexOfWidth, indexOfEndOfWidth - indexOfWidth);
			dimensions.x = atoi(widthValue.c_str()) /1024.0f;

			//height
			size_t indexOfHeight = line.find("height=\"", indexOfEndOfWidth) + 8;
			size_t indexOfEndOfHeight = line.find("\"", indexOfHeight);
			std::string HeightValue = line.substr(indexOfHeight, indexOfEndOfHeight - indexOfHeight);
			dimensions.y = atoi(HeightValue.c_str()) / 1024.0f;

			//vertex and texture coordinates
			textureCoordinates[0] = uvCoords.x;
			textureCoordinates[1] = uvCoords.y + dimensions.y;
			textureCoordinates[2] = uvCoords.x + dimensions.x;
			textureCoordinates[3] = uvCoords.y;
			textureCoordinates[4] = uvCoords.x;
			textureCoordinates[5] = uvCoords.y;
			textureCoordinates[6] = uvCoords.x + dimensions.x;
			textureCoordinates[7] = uvCoords.y;
			textureCoordinates[8] = uvCoords.x;
			textureCoordinates[9] = uvCoords.y + dimensions.y;
			textureCoordinates[10] = uvCoords.x + dimensions.x;
			textureCoordinates[11] = uvCoords.y + dimensions.y;

			float aspect = dimensions.x / dimensions.y;

			vertices[0] = -0.5f * aspect;
			vertices[1] = -0.5f;
			vertices[2] = 0.5f * aspect;
			vertices[3] = 0.5f; //bottom
			vertices[4] = -0.5f * aspect;
			vertices[5] = 0.5f;
			vertices[6] = 0.5f * aspect;
			vertices[7] = 0.5f;
			vertices[8] = -0.5f * aspect;
			vertices[9] = -0.5f;
			vertices[10] = 0.5f * aspect;
			vertices[11] = -0.5f;

			break;
		}
	}

	//error checking
	if (create == false)
		std::cerr << "The image was not found in the spritesheet." << std::endl;
};

void Entity::Draw(ShaderProgram* program, Matrix &modelMatrix)
{
	//Modify matrix based on vector values
	modelMatrix.identity();

	if (!position.isEmpty())
		modelMatrix.setPosition(position.x, position.y, position.z);
	if (!scale.isEmpty())
		modelMatrix.setScale(scale.x, scale.y, scale.z);
	if (!rotate.isEmpty())
		modelMatrix.setRotation(rotate.x);

	program->setModelMatrix(modelMatrix);
	
	//texture
	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, textureCoordinates);
	glEnableVertexAttribArray(program->texCoordAttribute);

	//Image
	glBindTexture(GL_TEXTURE_2D, texture);
	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program->positionAttribute);
	glDrawArrays(GL_TRIANGLES, 0, 6);
}

Vector3 Entity::getDimensions()
{
	return dimensions;
}

